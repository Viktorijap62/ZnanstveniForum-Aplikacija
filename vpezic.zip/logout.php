<?php
session_start();

if (session_id() != "") {
    session_unset();
    session_destroy();
}

header('location: login.php');
?>