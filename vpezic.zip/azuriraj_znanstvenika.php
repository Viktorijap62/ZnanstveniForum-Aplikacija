<?php
include("zaglavlje.php");
$veza = spojiSeNaBazu();

if (isset($_GET['submit'])){

        $upit = "
        UPDATE `korisnik` SET 
        `ime`='{$_GET['ime']}',
        `prezime`='{$_GET['prezime']}',
        `slika`='{$_GET['slika']}',
        `titula`='{$_GET['titula']}',
        `radno_mjesto`='{$_GET['radno_mjesto']}',
        `opis`='{$_GET['opis']}' 
        WHERE korisnik_id = '{$_SESSION['aktivni_korisnik_id']}'
        ";
        izvrsiUpit($veza, $upit);

      if (isset($_GET['znanstveno_podrucje'])){
            $sql = "INSERT INTO `zahtjev_podrucja`(`moderator_id`, `znanstveno_podrucje_id`, `status`) VALUES ('{$_SESSION['aktivni_korisnik_id']}','{$_GET['znanstveno_podrucje']}','2')";
            izvrsiUpit($veza, $sql);
        }
}

$upit_ima_zahtjeva = "SELECT * FROM `zahtjev_podrucja` WHERE moderator_id = {$_SESSION['aktivni_korisnik_id']};";
    $rez_ima_zahtjeva = izvrsiUpit($veza, $upit_ima_zahtjeva);

    if (mysqli_num_rows($rez_ima_zahtjeva) == 0) {
        $rez_ima_zahtjeva = mysqli_fetch_array($rez_ima_zahtjeva);
        $zahtjev_poslan = false;
    } else $zahtjev_poslan = true;

$upit_ima_podrucje = "SELECT znanstveno_podrucje_id FROM korisnik WHERE korisnik_id = {$_SESSION['aktivni_korisnik_id']}";
$red_ima_podrucje = mysqli_fetch_array(izvrsiUpit($veza, $upit_ima_podrucje));

if ($red_ima_podrucje['znanstveno_podrucje_id'] != NULL) $ima_podrucje = true;
else $ima_podrucje = false;


    if ($ima_podrucje){
        $upit = "SELECT korisnik.*, znanstveno_podrucje.naziv FROM `korisnik` 
        INNER JOIN znanstveno_podrucje 
        ON korisnik.znanstveno_podrucje_id = znanstveno_podrucje.znanstveno_podrucje_id 
        WHERE korisnik_id = {$_SESSION['aktivni_korisnik_id']}";
        $rezultat = izvrsiUpit($veza, $upit);
        $red = mysqli_fetch_array($rezultat);
    } else {
        $upit = "SELECT korisnik.* FROM `korisnik` 
        WHERE korisnik_id = {$_SESSION['aktivni_korisnik_id']} ";
        $rezultat = izvrsiUpit($veza, $upit);
        $red = mysqli_fetch_array($rezultat);
    }


$upit = "SELECT * FROM `znanstveno_podrucje`";
$rez = izvrsiUpit($veza, $upit);
?>

<article>
    <div id="opis">
        <h2>Ažuriraj podatke znanstvenika</h2>
    </div>
    <br/>

    <form action='<?= $_SERVER['PHP_SELF']?>' method='get'>
        <table>
            <thead>
            </thead>
            <tbody>
                <tr>
                    
                    <td>Ime</td>
                    <td><input type="text" name='ime' value='<?=$red['ime']?>'></td>
                </tr>
                <tr>
                    <td>Prezime</td>
                    <td><input type="text" name='prezime' value='<?= $red['prezime'] ?>'></td>
                <tr>
                    <td>Slika</td>
                    <td><input type='text' name='slika' value='<?= $red['slika'] ?>'></td>
                </tr>
                <tr>
                    <td>Titula</td>
                    <td><input type='text' name='titula' value='<?= $red['titula'] ?>'></td>
                </tr>
                <tr>
                    <td>Radno mjesto</td>
                    <td><input type='text' name='radno_mjesto' value='<?= $red['radno_mjesto'] ?>'></td>
                </tr>
                <tr>
                    <td>Opis</td>
                    <td><input type='text' name='opis' value='<?= $red['opis'] ?>'></td>
                </tr>
                <tr>
                    <td>Znanstveno područje</td>
                    <td> <?php
                        if (isset($_GET['znanstveno_podrucje'])){
                            echo "Zahtjev za promjenom područja je poslan<br>";
                        }
                        ?>
                    <select id="znanstveno_podrucje" name="znanstveno_podrucje" <?php if(!isset($red['znanstveno_podrucje_id']) && empty($red['znanstveno_podrucje_id'])) echo " disabled " ?>>
                            <?php
                            while ($red_znanstveno = mysqli_fetch_array($rez)) {

                                echo "<option value='{$red_znanstveno['znanstveno_podrucje_id']}'";

                                if ($red_znanstveno['znanstveno_podrucje_id'] == $red['znanstveno_podrucje_id']){
                                    echo " selected ";
                                }
                                
                                
                                echo ">{$red_znanstveno['naziv']}</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type='submit' name='submit' value='Ažuriraj'></td>
                </tr>

            </tbody>
        </table>
    </form>

    <br />

</article>
</section>

<?php
include("podnozje.php");
?>