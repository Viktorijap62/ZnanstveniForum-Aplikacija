<?php
include("zaglavlje.php");
$bp = spojiSeNaBazu();
?>
<?php
$greska = "";
if (isset($_POST['submit'])) {
	foreach ($_POST as $key => $value) if (strlen($value) == 0) $greska = "Sva polja za unos su obavezna";
	if (empty($greska)) {
		if (isset($_POST['komentar_id'])) $id = $_POST['komentar_id'];
		else $id = 0;
		$korisnik_id = $_POST['korisnik'];
		$podrucje_id = $_POST['znanstveno_podrucje_id'];
		$sadrzaj = $_POST['sadrzaj'];
		if ($id == 0) {

			$moje_podrucje_rez = mysqli_fetch_array(izvrsiUpit($bp, "SELECT znanstveno_podrucje_id FROM korisnik WHERE korisnik_id = {$_SESSION['aktivni_korisnik_id']}"));
			$moje_podrucje = $moje_podrucje_rez[0];
			if ($podrucje_id = $moje_podrucje) {
				$sql = "INSERT INTO `komentar`(`znanstveno_podrucje_id`, `korisnik_id`, `sadrzaj`, `datum_vrijeme_kreiranja`, `komentar_znanstvenika`) 
					VALUES ('{$podrucje_id}','{$korisnik_id}','{$sadrzaj}', NOW(),'TRUE')";
			} else {
				$sql = "INSERT INTO `komentar`(`znanstveno_podrucje_id`, `korisnik_id`, `sadrzaj`, `datum_vrijeme_kreiranja`, `komentar_znanstvenika`) 
						VALUES ('{$podrucje_id}','{$korisnik_id}','{$sadrzaj}', NOW(),'FALSE')";
			}
		} else {
			$sql = "UPDATE komentar SET
					komentar_id='$id',
                    id_tip='$tip',
					znanstveno_podrucje_id='$podrucje_id',
                    korime='$korime',
					sadrzaj='$sadrzaj',
					ime='$ime',
					datum_i_vrijeme='$datum_vrijeme',
					WHERE komentar_id='$id'
				";
		}
		izvrsiUpit($bp, $sql);
		header("Location:komentari.php?komentari={$podrucje_id}");
	}
}
if (isset($_GET['komentar'])) {
	$id = $_GET['komentar'];
	if ($aktivni_korisnik_id == 2) $id = $_SESSION["aktivni_korisnik_id"];
	$sql = "SELECT * FROM komentar WHERE komentar_id='$id'";
	$rs = izvrsiUpit($bp, $sql);
	list($id, $podrucje_id, $ime, $prezime, $sadrzaj, $datum_vrijeme) = mysqli_fetch_array($rs);
} else {
	$id = "";
	$tip = 2;
	$podrucje_id = "";
	$ime = "";
	$prezime = "";
	$korime = "";
	$sadrzaj = "";
	$datum_vrijeme = "";
}
if (isset($_POST['reset'])) header("Location:komentar.php");

$upit = "SELECT * FROM `znanstveno_podrucje`";
$rez = izvrsiUpit($bp, $upit);

?>
<form method="POST" action="<?php if (isset($_GET['komentar'])) echo "komentar.php?komentar=$id";
							else echo "komentar.php"; ?>">
	<table>
		<caption>
			<?php
			if (isset($id) && $aktivni_korisnik_id == $id) echo "Uredi moje podatke";
			else if (!empty($id)) echo "Uredi komentar";
			else echo "Dodaj komentar";
			?>
		</caption>
		<tbody>
			<tr>
				<td colspan="2">
					<input type="hidden" name="novi" value="<?php if (!empty($id)) echo $id;
					else echo 0; ?>" />
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<label class="greska"><?php if ($greska != "") echo $greska; ?></label>
				</td>
			</tr>
			<tr>
				<td class="lijevi">
					<label for="sadrzaj"><strong>Sadržaj:</strong></label>
				</td>
				<td>
					<input type="text" name="sadrzaj" id="sadrzaj" value="<?php if (!isset($_POST['sadrzaj'])) echo $sadrzaj;
					else echo $_POST['sadrzaj']; ?>" size="120" minlength="5" maxlength="250" placeholder="Unesi sadržaj komentara" required="required" />
				</td>
			</tr>
			<tr>
				<td>
					<label for="znanstveno_podrucje_id"><strong>Znanstveno područje:</strong></label>
				</td>
				<td>
					<select id="znanstveno_podrucje_id" name="znanstveno_podrucje_id">
						<?php
						while ($red = mysqli_fetch_array($rez)) {

							echo "<option value='{$red['znanstveno_podrucje_id']}'>{$red['naziv']}</option>";
						}
						?>
					</select>
					<input type="hidden" name='korisnik' value="<?php echo $_SESSION['aktivni_korisnik_id'] ?>">

				</td>
			<tr>

				<td colspan="2" style="text-align:center;">
					<?php
					if (isset($id) && $aktivni_korisnik_id == $id || !empty($id)) echo '<input type="submit" name="submit" value="Pošalji"/>';
					else echo '<input type="submit" name="reset" value="Izbriši"/><input type="submit" name="submit" value="Pošalji"/>';
					?>
				</td>
			</tr>
		</tbody>
	</table>
</form>
<?php
zatvoriVezuNaBazu($bp);
include("podnozje.php");
?>