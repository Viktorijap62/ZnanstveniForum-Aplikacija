<?php
include("zaglavlje.php");
$bp = spojiSeNaBazu();

$greska = "";


if (isset($_GET['podrucje'])) {
	$id_podrucja = $_GET['podrucje'];
} else $id_podrucja = $_POST['podrucje'];

if (isset($_POST['submit'])) {
	$naziv = $_POST['naziv'];
	$opis = $_POST['opis'];
	$sql = "UPDATE znanstveno_podrucje SET
			`naziv`='$naziv', `opis`='$opis'
			WHERE znanstveno_podrucje_id=$id_podrucja;";
	izvrsiUpit($bp, $sql);
}

$sql_podaci = "SELECT * FROM znanstveno_podrucje WHERE znanstveno_podrucje_id = $id_podrucja";
$podaci = mysqli_fetch_array(izvrsiUpit($bp, $sql_podaci));

?>
<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	<table>
		<caption>Ažuriraj područje</caption>
		<tbody>
			<tr>
				<td colspan="2">
					<input type="hidden" name="novi" />
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<label class="greska"><?php if ($greska != "") echo $greska; ?></label>
				</td>
			</tr>
			<tr>
				<td class="lijevi">
					<label for="naziv"><strong>Naziv podrucja:</strong></label>
				</td>
				<td>
					<input type="text" name="naziv" id="naziv" size="120" maxlength="100" value='<?= $podaci['naziv'] ?>' placeholder="Naziv podrucja treba sadržavati puni naziv, može uključivati praznine i sadržati do 50 znakova">
				</td>
			</tr>
			<tr>
				<td>
					<label for="opis"><strong>Opis podrucja:</strong></label>
				</td>
				<td>
					<input type="text" name="opis" id="opis" size="120" maxlength="150" value='<?= $podaci['opis'] ?>' placeholder="Opis podrucja treba sadržavati detaljniji opis navedenog područja, može uključivati praznine i sadržati do 150 znakova">
					<input type=hidden name=podrucje value=<?= $id_podrucja ?> >
				</td>
			</tr>

			<tr>
				<td colspan="2" style="text-align:center;">
					<input type="submit" name="reset" value="Izbriši" /><input type="submit" name="submit" value="Pošalji" />
				</td>
			</tr>
		</tbody>
	</table>
</form>
<?php
zatvoriVezuNaBazu($bp);
include("podnozje.php");
?>