 <?php 
	include("zaglavlje.php");
?>


<div class="profil">
	<span class="profil-natpis" style="text-align:center;">Podaci o autoru</span>
	<div class="profil-container" style="align-items: center;">
		<label class="profil-label"><img width="300" height="400" src="./slike/viktorija.jpg"/></label>
	</div>
	<div class="profil-container"div style="align-items: center;">
		<label class="profil-label"> <strong>Ime:</strong> Viktorija</label>
	</div>
	<div class="profil-container"div style="align-items: center;">
		<label class="profil-label"> <strong>Prezime:</strong> Pezić</label>
	</div>
	<div class="profil-container"div style="align-items: center;">
		<label class="profil-label"> <strong>Email:</strong> vpezic@foi.hr</label>
	</div>
		<div class="profil-container"div style="align-items: center;">
		<label class="profil-label"> <strong>Telefonski broj:</strong> 099 999 999</label>
	</div>
		<div class="profil-container"div style="align-items:center;">
		<label class="profil-label"> <strong>Centar i godina:</strong> Zabok, 2021./2022.</label>
	</div>
	</div>
		<div class="profil-container"div style="align-items: center;">
		<label class="profil-label"> <strong>Broj indexa:</strong> Z-44978 </label>
	</div>
</div>
<br>
<br>
<?php
include("podnozje.php");
?>
