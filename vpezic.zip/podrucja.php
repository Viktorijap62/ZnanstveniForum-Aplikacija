<?php 
	include("zaglavlje.php");
	$bp=spojiSeNaBazu();
?>

<?php 
	
	$sql="SELECT COUNT(*) FROM znanstveno_podrucje";
	$rs=izvrsiUpit($bp,$sql);
	$red=mysqli_fetch_array($rs);
	$broj_redaka=$red[0];
	$broj_stranica=ceil($broj_redaka/$vel_str);
	
	$sql="SELECT * FROM znanstveno_podrucje ORDER BY znanstveno_podrucje_id LIMIT ".$vel_str;
	if(isset($_GET['stranica'])){
		$sql=$sql." OFFSET ".(($_GET['stranica']-1)*$vel_str);
		$aktivna=$_GET['stranica'];
	}
	else $aktivna=1;
	$rs=izvrsiUpit($bp,$sql);
	
	echo "<table>";
    echo "<caption>Popis trenutnih područja</caption>";
	echo "<thead><tr>
			<th>Naziv</th>
			<th>Opis</th>
			<th></th>";
	echo "</tr></thead>";
	
	echo "<tbody>";
	while(list($id, $naziv, $opis)=mysqli_fetch_array($rs)){
		echo "<tr>
			<td><a href='komentari.php?komentari=$id'>$naziv</td>
			<td>$opis</td>";
			if($aktivni_korisnik_tip_id==0||$aktivni_korisnik_tip_id==1)echo "<td><a class='link' href='podrucje.php?podrucje=$id'>UREDI</a></td>";
			else if(isset($_SESSION["aktivni_korisnik_tip_id"])&&$_SESSION["aktivni_korisnik_tip_id"]==$id) echo '<td><a class="link" href="podrucje.php?podrucje='.$_SESSION["aktivni_korisnik_id"].'">UREDI</a></td>';
			else echo "<td></td>";
		echo "</tr>";
	}

	echo "</tbody>";
	echo "</table>";
	
	echo '<div id="paginacija">';
	
	if ($aktivna!=1){
		$prethodna=$aktivna-1;
		echo "<a class='link' href=\"podrucja.php?stranica=".$prethodna."\">&lt;</a>";
	}
	for($i=1;$i<=$broj_stranica;$i++){
		echo "<a class='link";
		if($aktivna==$i)echo " aktivna"; 
		echo "' href=\"podrucja.php?stranica=".$i."\">$i</a>";
	}
	
	if($aktivna<$broj_stranica){
		$sljedeca=$aktivna+1;
		echo "<a class='link' href=\"podrucja.php?stranica=".$sljedeca."\">&gt;</a>";
	}
	echo '<br/>';
	if($aktivni_korisnik_tip_id==0||$aktivni_korisnik_tip_id==1)echo '<a class="link" href="dodajpodrucje.php">DODAJ PODRUČJE</a>';
	echo '</div>';

?>

<?php 
	zatvoriVezuNaBazu($bp);
?>