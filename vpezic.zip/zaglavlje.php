<?php
	include("baza.php");
	if(session_id()=="")session_start();

	$trenutna=basename($_SERVER["PHP_SELF"]);
	$putanja=$_SERVER['REQUEST_URI'];
	$aktivni_korisnik_id=0;
	$aktivni_korisnik_tip_id=-1;
	$vel_str=5; 
	$vel_str_podrucja=10; 

	if(isset($_SESSION['aktivni_korisnik_id'])){
		$aktivni_korisnik_id=$_SESSION['aktivni_korisnik_id'];
		$aktivni_korisnik_ime_i_prezime=$_SESSION['aktivni_korisnik_ime_i_prezime'];
		$aktivni_korisnik_tip_id=$_SESSION['aktivni_korisnik_tip_id'];
		
		date_default_timezone_set("Europe/Zagreb");
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Znanstveni forum</title>
		<meta name="autor" content="Viktorija Pezić"/>
		<meta name="datum" content="10.02.2023."/>
		<meta charset="utf-8"/>
		<link href="style.css" rel="stylesheet" type="text/css"/>
	</head>
	<body>
		<header>
			<span>
				<strong>Izgradnja Web aplikacija - Znanstveni forum</strong>
				<br/>
				<?php
					echo "<strong>Lokacija: </strong>".$trenutna."<br/>";
					if($aktivni_korisnik_id===0){
						echo "<span><strong>Status: </strong> Neprijavljeni korisnik </span><br/>";
						echo "<a class='link' href='login.php'>prijava</a>";
					}
					else{
						
						switch ($aktivni_korisnik_tip_id) {
							case 0:
								$naziv_tipa = "administrator";
								break;
							case 1:
								$naziv_tipa = "moderator";
								break;
							case 2:
								$naziv_tipa = "korisnik";
								break;
							default:
								$naziv_tipa = "nepoznata vrijednost";
						}

						echo "<span><strong>Dobrodošli,</strong> $aktivni_korisnik_ime_i_prezime </span><br/>";
						echo "<span><strong>Status:</strong> $naziv_tipa<br>";
						echo "<a class='link' href='login.php?logout=1'>odjava</a>";
					}
				?>
			</span>
		</header>
		<nav id="navigacija" class="menu">
			<?php
			echo '<a href="index.php">Početna</a>';
			echo "<a href='znanstvenici.php'>Znanstvenici</a>";

			if (isset($_SESSION["aktivni_korisnik_id"]) ){
				echo '<a href="podrucja.php">Znanstvena područja</a>';

				if ($_SESSION['aktivni_korisnik_tip_id'] < 2) {
				}

				if ($_SESSION['aktivni_korisnik_tip_id'] == 0){
					echo "<a href='korisnici.php'>Korisnici</a>";
					echo "<a href='zahtjevi.php'>Zahtjevi za promjenu područja</a>";
					echo "<a href='statistika.php'>Statistika komentara</a>";
					

				}
			} 

			echo '<a href="autor.php">O autoru</a>';

			?>
		</nav>
		<section id="sadrzaj">
