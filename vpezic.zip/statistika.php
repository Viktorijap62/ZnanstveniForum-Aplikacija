<?php
include("zaglavlje.php");
$bp = spojiSeNaBazu();

$sql = "SELECT COUNT(komentar.komentar_id) as broj_komentara, znanstveno_podrucje.naziv FROM komentar INNER JOIN znanstveno_podrucje ON komentar.znanstveno_podrucje_id = znanstveno_podrucje.znanstveno_podrucje_id GROUP BY komentar.znanstveno_podrucje_id;
    ";
$rs = izvrsiUpit($bp, $sql);

zatvoriVezuNaBazu($bp);
?>

<article>
    <div id="opis">
        <h2>Statistika broja komentara po znanstvenom području</h2>
    </div>

    <table>

        <thead>
            <th>Znanstveno područje</th>
            <th>Ukupno komentara</th>
        </thead>
        <tbody>
            <?php
                while($red = mysqli_fetch_array($rs)){
                    echo "<tr>
                        <td>{$red['naziv']}</td>
                        <td>{$red['broj_komentara']}</td>
                        </tr>
                    ";
                }
            ?>
        </tbody>
    </table>


</article>


<?php
include("podnozje.php");
?>