<?php
	include("zaglavlje.php");
?>

<article>
	<div id="opis">
		<h2>Znanstveni forum</h2>
		<p>Jednostavna aplikacija gdje možete raspravljati sa znanstvenicima.</p>
	</div>
	<br/>
	<table>
		<caption>Korisnici sustava</caption>
		<thead>
			<tr>
				<th class="lijevi">Popis korisnika</th>
				<th>Opis korisnika</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>Administrator</td>
				<td>Dodavanje i uređivanje korisnika i njihovih tipova i unosi i ažurira znanstvena područja.</td>
			</tr>
			<tr>
				<td>Znanstvenik</td>
				<td>Ažurira svoje podatke i može poslati zahtjev administratoru za odobrenje znanstvenog područja rada.</td>
			</tr>
			<tr>
				<td>Korisnik</td>
				<td>Može pristupiti popisu znanstvenih područja, pisati komentare i vidjeti detalje o znanstevniku.</td>
			</tr>
			<tr>
				<td>Anonimni korisnik</td>
				<td>Pregledavanje popisa znanstvenika.</td>
			</tr>
		</tbody>
	</table>
	<br/>
	<table>
		<caption>Datoteke sustava</caption>
		<thead>
			<tr>
				<th class="lijevi">Popis datoteka</th>
				<th>Opis datoteka</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>autor.php</td>
				<td>Osnovni podaci o autoru</td>
			</tr>
			<tr>
				<td>azuriraj_znanstvenika.php</td>
				<td>Mogućnost promijene podataka od odabranog znanstvenika</td>
			</tr>
			<tr>
				<td>baza.php</td>
				<td>Skripta za rad s bazom podataka</td>
			</tr>
			<tr>
				<td>dodajpodrucje.php</td>
				<td>Obrazac za dodavanje novog područja</td>
			</tr>
			<tr>
				<td>index.php</td>
				<td>Kratak opis aplikacije</td>
			</tr>
			<tr>
				<td>komentar.php</td>
				<td>Obrazac za unos novog komentara</td>
			</tr>
			<tr>
				<td>komentari.php</td>
				<td>Tablica svih komentara određenog područja, mogućnost filtriranja</td>
			</tr>
			<tr>
				<td>korisnici.php</td>
				<td>Tablica koja izlistava korisnike, ako je tip korisnika administrator ili zaposlenik postoji mogućnost dodavanja novog korisnika</td>
			</tr>
			<tr>
				<td>korisnik.php</td>
				<td>Obrazac za unos novog ili uređivanje postojećeg korisnika</td>
			</tr>
			<tr>
				<td>login.php</td>
				<td>Obrazac za prijavu u sustav</td>
			</tr>
			<tr>
				<td>logout.php</td>
				<td>Obrazac za odjavu iz sustava</td>
			</tr>
			<tr>
				<td>podnozje.php</td>
				<td>Podnožje stranice</td>
			</tr>
			<tr>
				<td>podrucja.php</td>
				<td>Tablica koja izlistava područja, ako je tip korisnika administrator ili zaposlenik postoji mogućnost dodavanja novog područja</td>
			</tr>
			<tr>
				<td>podrucje.php</td>
				<td>Obrazac za unos novog ili uređivanje postojećeg područja</td>
			</tr>
			<tr>
				<td>statistika.php</td>
				<td>Tablica koja prikazuje broj komentara za svako područje</td>
			</tr>
			<tr>
				<td>style.css</td>
				<td>CSS upute</td>
			</tr>
			<tr>
				<td>zaglavlje.php</td>
				<td>Zaglavlje stranice</td>
			</tr>
			<tr>
				<td>zahtjevi.php</td>
				<td>Popis odobrenih, odbijenih ili zahtjeva koji su na čekanju za promjenu područja</td>
			</tr>
			<tr>
				<td>znanstvenici.php</td>
				<td>Tablica svih postojećih znanstvenika</td>
			</tr>
			<tr>
				<td>znanstvenik.php</td>
				<td>Detaljni podaci o znanstveniku</td>
			</tr>
		</tbody>
	</table>
</article>

<?php
	include("podnozje.php");
?>
