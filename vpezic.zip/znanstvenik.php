<?php
	include("zaglavlje.php");
    $veza = spojiSeNaBazu();

    if (isset($_GET['id'])){
        $upit = "SELECT korisnik.*, znanstveno_podrucje.naziv FROM `korisnik` 
        INNER JOIN znanstveno_podrucje 
        ON korisnik.znanstveno_podrucje_id = znanstveno_podrucje.znanstveno_podrucje_id WHERE korisnik_id = {$_GET['id']}";
        $rezultat = izvrsiUpit($veza, $upit);
    }
   

?>

<article>
	<div id="opis">
		<h2>Znanstvenik</h2>
	</div>
	<br/>
    
    <table>
        <thead>
        </thead>
        <tbody>
            <?php
                while($red = mysqli_fetch_array($rezultat)){
                    echo "
                        <tr>
                            <td>Ime i prezime</td>
                            <td>{$red['ime']} {$red['prezime']}</td>
                        </tr>
                        <tr>
                            <td>Slika</td>
                            <td><img src='{$red['slika']}'></td>
                        </tr>
                        <tr>
                            <td>Titula</td>
                            <td>{$red['titula']}</td>
                        </tr>
                        <tr>
                            <td>Radno mjesto</td>
                            <td>{$red['radno_mjesto']}</td>
                        </tr>
                        <tr>
                            <td>Opis</td>
                            <td>{$red['opis']}</td>
                        </tr>
                        <tr>
                            <td>Znanstveno područje</td>
                            <td>{$red['naziv']}</td>
                        </tr>
                    
                    ";
                }

            ?>

        </tbody>
    </table>
	
	<br/>
	
</article>
</section>

<?php
	include("podnozje.php");
?>
