<?php
include("zaglavlje.php");
$bp = spojiSeNaBazu();

if (isset($_GET['komentari'])) {
	if (isset($_GET['submit'])) {
		if (!empty($_GET['znanstvenik'])) {
			if (!empty($_GET['vrijeme-od']) && !empty($_GET['vrijeme-do'])) {
				$vrijeme_od_filter = date("Y-m-d H:i:s", strtotime($_GET['vrijeme-od']));
				$vrijeme_do_filter = date("Y-m-d H:i:s", strtotime($_GET['vrijeme-do']));

				$sql = "SELECT komentar.*, korisnik.ime, korisnik.prezime FROM komentar 
						INNER JOIN korisnik ON komentar.korisnik_id = korisnik.korisnik_id 
						WHERE komentar.znanstveno_podrucje_id = {$_GET['komentari']} 
						AND komentar.korisnik_id = {$_GET['znanstvenik']} 
						AND komentar.datum_vrijeme_kreiranja 
						BETWEEN '{$vrijeme_od_filter}' AND '{$vrijeme_do_filter}' ORDER BY komentar.datum_vrijeme_kreiranja DESC;";
			} else {
				$sql = "SELECT komentar.*, korisnik.ime, korisnik.prezime FROM komentar 
						INNER JOIN korisnik ON komentar.korisnik_id = korisnik.korisnik_id 
						WHERE komentar.znanstveno_podrucje_id = {$_GET['komentari']} 
						AND komentar.korisnik_id = {$_GET['znanstvenik']} 
						ORDER BY komentar.datum_vrijeme_kreiranja DESC;";
			}
		} else if (empty($_GET['znanstvenik']) && !empty($_GET['vrijeme-od']) && !empty($_GET['vrijeme-do'])) {
			$vrijeme_od_filter = date("Y-m-d H:i:s", strtotime($_GET['vrijeme-od']));
			$vrijeme_do_filter = date("Y-m-d H:i:s", strtotime($_GET['vrijeme-do']));

			$sql = "SELECT komentar.*, korisnik.ime, korisnik.prezime FROM komentar 
					INNER JOIN korisnik ON komentar.korisnik_id = korisnik.korisnik_id 
					WHERE komentar.znanstveno_podrucje_id = {$_GET['komentari']} 
					AND komentar.datum_vrijeme_kreiranja 
					BETWEEN '{$vrijeme_od_filter}' AND '{$vrijeme_do_filter}' ORDER BY komentar.datum_vrijeme_kreiranja DESC;";
		} else if (empty($_GET['znanstvenik']) && empty($_GET['vrijeme-od']) && empty($_GET['vrijeme-do'])) {
			$sql = "SELECT komentar.*, korisnik.ime, korisnik.prezime FROM komentar 
					INNER JOIN korisnik 
					ON komentar.korisnik_id = korisnik.korisnik_id
					WHERE komentar.znanstveno_podrucje_id = {$_GET['komentari']}
					ORDER BY komentar.datum_vrijeme_kreiranja DESC;";
		}
	} else {
		$sql = "SELECT komentar.*, korisnik.ime, korisnik.prezime FROM komentar 
				INNER JOIN korisnik 
				ON komentar.korisnik_id = korisnik.korisnik_id
				WHERE komentar.znanstveno_podrucje_id = {$_GET['komentari']}
				ORDER BY komentar.datum_vrijeme_kreiranja DESC;";
	}

	$rs = izvrsiUpit($bp, $sql);

	$upit_znanstvenika_filtriranje = "SELECT DISTINCT korisnik.ime, korisnik.prezime, korisnik.korisnik_id FROM komentar INNER JOIN korisnik ON komentar.korisnik_id = korisnik.korisnik_id 
										WHERE komentar.znanstveno_podrucje_id = {$_GET['komentari']}
										AND korisnik.tip_korisnika_id = 1;";
	$rezultat_znanstvenika_filtriranje = izvrsiUpit($bp, $upit_znanstvenika_filtriranje);
} else {
}

echo "
<div id='forma-filtriranje'>
	<form method='get' action='{$_SERVER['PHP_SELF']}'>
		<select name='znanstvenik'>
			<option value='' selected>-</option>";

while ($red = mysqli_fetch_array($rezultat_znanstvenika_filtriranje)) {
	echo "<option value='{$red['korisnik_id']}'>{$red['ime']} {$red['prezime']}</option>";
}

echo "</select>
		<input type='text' name='vrijeme-od' placeholder='12:00:00 01.01.2020.'>
		<input type='text' name='vrijeme-do' placeholder='12:00:00 01.01.2022.'>
		<input type='hidden' name='komentari' value='{$_GET['komentari']}'>
		<input type='submit' name='submit' value='Filtriraj'>
		</form>
		</div>
	";

echo "<div id='dodaj-komentar'>
		<a href='komentar.php' ><button>Dodaj komentar</button></a>
	</div>";

echo "<table>";
echo "<caption>Komentari</caption>";
echo "<thead><tr>
			
			<th>Ime i prezime</th>
			<th>Sadržaj</th>
			<th>Datum i vrijeme kreiranja</th>
			<th></th>";
echo "</tr></thead>";

echo "<tbody>";
while (list($id, $podrucje_id, $korisnik_id, $sadrzaj, $datum_vrijeme, $komentar_znanstvenika, $ime, $prezime) = mysqli_fetch_array($rs)) {

	$datum_vrijeme = date("d.m.Y H:i:s", strtotime($datum_vrijeme));

	if ($komentar_znanstvenika == 1) {
		echo "<tr class='naglaseno'>";
		echo "
				<td><a href='znanstvenik.php?id=$korisnik_id' class='link-znanstvenika'>$ime $prezime</a></td>
				<td>$sadrzaj</td>
				<td>$datum_vrijeme</td>";
	} else {
		echo "<tr>";
		echo "
				<td>$ime $prezime</td>
				<td>$sadrzaj</td>
				<td>$datum_vrijeme</td>";
	}


	if ($aktivni_korisnik_tip_id == 0) echo "<td><a href='komentar.php?komentar=$id' class='link'>UREDI</a></td>";

	echo "</tr>";
}


echo "</tbody>";
echo "</table>";


echo '<div id="paginacija">';


echo '<br/>';
if ($aktivni_korisnik_tip_id == 0) echo '<a class="link" href="komentar.php">DODAJ KOMENTAR</a>';
echo '</div>';;

if (isset($_GET['obrisi-komentar'])) {
	$id = $_GET['obrisi-komentar'];
	$sql = "DELETE FROM komentar WHERE komentar_id = '$id'";
	izvrsiUpit($bp, $sql);
	header("Location:komentari.php");
}

?>

<?php
zatvoriVezuNaBazu($bp);
?>