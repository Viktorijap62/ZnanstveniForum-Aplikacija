<?php
include("zaglavlje.php");
$veza = spojiSeNaBazu();
$podrucje = false;
if (isset($_POST['submit'])) {
    $sql = "INSERT INTO `zahtjev_podrucja`(`moderator_id`, `znanstveno_podrucje_id`, `status`) VALUES ('{$_SESSION['aktivni_korisnik_id']}','{$_POST['podrucje']}','2')";
    izvrsiUpit($veza, $sql);
}

$upit = "SELECT * FROM `korisnik` WHERE tip_korisnika_id = 1 ORDER BY `korisnik`.`prezime` DESC";
$rezultat = izvrsiUpit($veza, $upit);

if (isset($_SESSION['aktivni_korisnik_tip_id']) && $_SESSION['aktivni_korisnik_tip_id'] < 2) {
    $upit = "SELECT znanstveno_podrucje_id FROM korisnik WHERE korisnik_id = '{$_SESSION['aktivni_korisnik_id']}'";
    $rez = izvrsiUpit($veza, $upit);
    $red_podrucje = mysqli_fetch_array($rez);
    $podrucje = $red_podrucje['znanstveno_podrucje_id'];
}
$zahtjev_poslan = false;
if (isset($_SESSION['aktivni_korisnik_id'])){
    $upit_ima_zahtjeva = "SELECT * FROM `zahtjev_podrucja` WHERE moderator_id = {$_SESSION['aktivni_korisnik_id']};";
    $rez_ima_zahtjeva = izvrsiUpit($veza, $upit_ima_zahtjeva);
    if (mysqli_num_rows($rez_ima_zahtjeva) > 0) {
        $rez_ima_zahtjeva = mysqli_fetch_array($rez_ima_zahtjeva);
        $zahtjev_poslan = true;
    }
}
$upit = "SELECT * FROM `znanstveno_podrucje`";
$rez_sva_podrucja = izvrsiUpit($veza, $upit);

?>

<article>
    <div id="opis">
        <h2>Popis svih znanstvenika</h2>
    </div>
    <br />
    <?php
if (!isset($_SESSION['aktivni_korisnik_tip_id'])) {
    echo "";}
    else if ($podrucje == NULL && !$zahtjev_poslan) {
        echo 'Prijavljeni znanstvenik nema dodijeljeno znanstveno područje<br>';
        echo "<form action='{$_SERVER['PHP_SELF']}' method='post'>";
        echo "<input type=hidden name='zahtjev_poslan' value='1'>";

        echo "<select name='podrucje'>";

        while ($red_sva_podrucja = mysqli_fetch_array($rez_sva_podrucja)) {
            echo "<option value='{$red_sva_podrucja['znanstveno_podrucje_id']}'>{$red_sva_podrucja['naziv']}</option>";
        }

        echo "</select>";
        echo "<input type='submit' name='submit' value='Pošalji zahtjev administratoru'></form><br>";
    }
    else {
        echo "Zahtjev za odobravanjem znanstvenog područja je već poslan<br>";
    }
    if (isset($_SESSION['aktivni_korisnik_tip_id']) && $_SESSION['aktivni_korisnik_tip_id'] < 2) {
        echo '<a href="azuriraj_znanstvenika.php"><button>Ažuriraj moje podatke</button></a><br>';
    } else echo "";
    ?>
    <br />
    <div class="grid-container">


        <?php

        while ($red = mysqli_fetch_array($rezultat)) {
            echo "<div class='grid-item'>
            <img src='{$red['slika']}' class='grid-item-image' alt='{$red['ime']} {$red['prezime']}'>
            <p>{$red['titula']} <a href='znanstvenik.php?id={$red['korisnik_id']}' class='link-znanstvenika'>{$red['ime']} {$red['prezime']}</a></p>
            
            </div>
        ";
        }
        ?>
    </div>
    <br />

</article>
</section>

<?php
include("podnozje.php");
?>