<footer> 
            <address> Kontakt: <a href="mailto:vpezic@foi.hr">vpezic@foi.hr</a></address>
            <p>&copy; Viktorija Pezić</p>
        </footer>
