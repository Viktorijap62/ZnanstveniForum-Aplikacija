<?php
	include("zaglavlje.php");
	$bp=spojiSeNaBazu();
?>
<?php
	$greska="";
	if(isset($_POST['submit'])){
		foreach ($_POST as $key => $value)if(strlen($value)==0)$greska="Sva polja za unos su obavezna";
		if(empty($greska)){
			$id=$_POST['novi'];
			$tip=$_POST['tip'];
			$korime=$_POST['korime'];
			$ime=$_POST['ime'];
			$prezime=$_POST['prezime'];
			$lozinka=$_POST['lozinka'];
			$email=$_POST['email'];
			$slika=$_POST['slika'];

			if($id==0){
				$sql="INSERT INTO korisnik
				(tip_korisnika_id,korime,ime,prezime,lozinka,email,slika)
				VALUES
				($tip,'$korime','$ime','$prezime','$lozinka','$email','$slika');
				";
			}
			else{
				$sql="UPDATE `korisnik` SET 
					`tip_korisnika_id`='$tip',
					`korime`='$korime',
					`ime`='$ime',
					`prezime`='$prezime',
					`email`='$email',
					`lozinka`='$lozinka',
					`slika`='$slika'
					WHERE korisnik_id = '$id';
				";
			}
			izvrsiUpit($bp,$sql);
			header("Location:korisnici.php");
		}
	}
	if(isset($_GET['korisnik'])){
		$id=$_GET['korisnik'];
		if($aktivni_korisnik_id==2)$id=$_SESSION["aktivni_korisnik_id"]; 
		$sql="SELECT * FROM korisnik WHERE korisnik_id='$id'";
		$rs=izvrsiUpit($bp,$sql);
		list($id,$tip,$znanstveno_podrucje, $korime,$ime,$prezime,$email,$lozinka,$slika)=mysqli_fetch_array($rs);
	}
	else{
		$tip=2;
		$korime="";
		$ime="";
		$prezime="";
		$lozinka="";
		$email="";
		$slika="";
	}
	if(isset($_POST['reset']))header("Location:korisnik.php");
?>
<form method="POST" action="<?php if(isset($_GET['korisnik']))echo "korisnik.php?korisnik=$id";else echo "korisnik.php";?>">
	<table>
		<caption>
			<?php
				if(isset($id)&&$aktivni_korisnik_id==$id)echo "Uredi moje podatke";
				else if(!empty($id))echo "Uredi korisnika $ime";
				else echo "Dodaj korisnika";
			?>
		</caption>
		<tbody>
			<tr>
				<td colspan="2">
					<input type="hidden" name="novi" value="<?php if(!empty($id))echo $id;else echo 0;?>"/>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<label class="greska"><?php if($greska!="")echo $greska; ?></label>
				</td>
			</tr>
			<tr>
				<td class="lijevi">
					<label for="korime"><strong>Korisničko ime:</strong></label>
				</td>
				<td>
					<input type="text" name="korime" id="korime" value="<?php if(!isset($_POST['korime']))echo $korime; else echo $_POST['korime'];?>"
						size="120" minlength="1" maxlength="50"
						placeholder="Korisničko ime ne smije sadržavati praznine, treba uključiti minimalno 10 znakova i započeti malim početnim slovom"
						required="required"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="ime"><strong>Ime:</strong></label>
				</td>
				<td>
					<input type="text" name="ime" id="ime" value="<?php if(!isset($_POST['ime']))echo $ime; else echo $_POST['ime'];?>"
						size="120" minlength="1" maxlength="50" 
						placeholder="Ime treba započeti sa velikim početnim slovom"
						required="required"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="prezime"><strong>Prezime:</strong></label>
				</td>
				<td>
					<input type="text" name="prezime" id="prezime" value="<?php if(!isset($_POST['prezime']))echo $prezime; else echo $_POST['prezime'];?>"
						size="120" minlength="1" maxlength="50"
						placeholder="Prezime treba započeti sa velikim početnim slovom"
						required="required"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="lozinka"><strong>Lozinka:</strong></label>
				</td>
				<td>
					<input <?php if(!empty($lozinka))echo "type='text'"; else echo "type='password'";?>
						name="lozinka" id="lozinka" value="<?php if(!isset($_POST['lozinka']))echo $lozinka; else echo $_POST['lozinka'];?>"
						size="120" minlength="8" maxlength="50"
						placeholder="Lozinka treba sadržati minimalno 8 znakova uključujući jedno veliko i jedno malo slovo, jedan broj i jedan posebni znak"
						required="required"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="email"><strong>E-mail:</strong></label>
				</td>
				<td>
					<input type="email" name="email" id="email" value="<?php if(!isset($_POST['email']))echo $email; else echo $_POST['email'];?>"
						size="120" minlength="5" maxlength="50" 
						placeholder="Ispravan oblik elektroničke pošte je nesto@nesto.nesto"
						required="required"/>
				</td>
			</tr>
			<tr>
				<td>Tip korisnika:</td>
				<td>
					<input type=radio name=tip value=2 checked>Korisnik<br>
					<input type=radio name=tip value=1>Moderator<br>
					<input type=radio name=tip value=0>Administrator<br>
				</td>
			</tr>
			<tr>
				<td>
					<label for="slika"><strong>Slika:</strong></label>
				</td>
				<td>
				<?php
					$dir=scandir("korisnici");
					echo '<select id="slika" name="slika">';
					foreach($dir as $key => $value){
						if($key<2)continue;
						else if(strcmp((isset($_POST['slika'])?$_POST['slika']:$slika),"korisnici/".$value)==0){
							echo '<option value="'."korisnici/".$value.'"';
							echo ' selected="selected">'."korisnici/".$value;
							echo '</option>';
						}
						else{
							echo '<option value="'."korisnici/".$value.'">';
							echo "korisnici/".$value;
							echo '</option>';
						}
					}
					echo '</select>';
				?>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<?php
						if(isset($id)&&$aktivni_korisnik_id==$id||!empty($id))echo '<input type="submit" name="submit" value="Pošalji"/>';
						else echo '<input type="submit" name="reset" value="Izbriši"/><input type="submit" name="submit" value="Pošalji"/>';
					?>
				</td>
			</tr>
		</tbody>
	</table>
</form>
<?php
	zatvoriVezuNaBazu($bp);
	include("podnozje.php");
?>
