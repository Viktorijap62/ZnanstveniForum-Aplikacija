<?php
include("zaglavlje.php");
$bp = spojiSeNaBazu();
?>
<?php
$greska = "";
if (isset($_POST['submit'])) {
	$naziv = $_POST['naziv'];
	$opis = $_POST['opis'];
	$sql = "INSERT INTO znanstveno_podrucje
			(naziv, opis)
			VALUES ('$naziv','$opis');";

	izvrsiUpit($bp, $sql);
	header("Location: podrucja.php");
}

?>
<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	<table>
		<caption>Dodaj područje</caption>
		<tbody>
			<tr>
				<td colspan="2">
					<input type="hidden" name="novi" />
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<label class="greska"><?php if ($greska != "") echo $greska; ?></label>
				</td>
			</tr>
			<tr>
				<td class="lijevi">
					<label for="naziv"><strong>Naziv podrucja:</strong></label>
				</td>
				<td>
					<input type="text" name="naziv" id="naziv" size="120" maxlength="100" placeholder="Naziv podrucja treba sadržavati puni naziv, može uključivati praznine i sadržati do 50 znakova">
				</td>
			</tr>
			<tr>
				<td>
					<label for="opis"><strong>Opis podrucja:</strong></label>
				</td>
				<td>
					<input type="text" name="opis" id="opis" size="120" maxlength="150" placeholder="Opis podrucja treba sadržavati detaljniji opis navedenog područja, može uključivati praznine i sadržati do 150 znakova">
				</td>
			</tr>

			<tr>
				<td colspan="2" style="text-align:center;">
					<input type="submit" name="reset" value="Izbriši" /><input type="submit" name="submit" value="Pošalji" />
				</td>
			</tr>
		</tbody>
	</table>
</form>
<?php
zatvoriVezuNaBazu($bp);
include("podnozje.php");
?>