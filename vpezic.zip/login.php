<?php
	include("zaglavlje.php");
	$bp=spojiSeNaBazu();
	$obavijest = "Morate popuniti sva polja.";

	if(isset($_GET['logout'])){
			unset($_SESSION['aktivni_korisnik_tip_id']);
			unset($_SESSION["aktivni_korisnik_znanstveno_podrucje_id"]);
			unset($_SESSION["aktivni_korisnik_ime_i_prezime"]);
			unset($_SESSION["aktivni_korisnik_korime"]);
			unset($_SESSION["aktivni_korisnik_titula"]);
			unset($_SESSION["aktivni_korisnik_radno_mjesto"]);
			session_destroy();
			header("Location:index.php");}

	$greska= "";
	if(isset($_POST["korime"]) && isset($_POST ["lozinka"])){
		$korime=mysqli_real_escape_string($bp,$_POST['korime']);
		$lozinka=mysqli_real_escape_string($bp,$_POST['lozinka']);

		if(!empty($korime)&&!empty($lozinka)){
			$sql="SELECT korisnik_id,tip_korisnika_id,ime,prezime FROM korisnik WHERE korime='$korime' AND lozinka='$lozinka'";
			$rs=izvrsiUpit($bp,$sql);
			if(mysqli_num_rows($rs)==0)$greska="Ne postoji korisnik s navedenim korisničkim imenom i lozinkom";
			else{
				list($id,$tip,$ime,$prezime)=mysqli_fetch_array($rs);
				$_SESSION['aktivni_korisnik_id']=$id;
				$_SESSION['aktivni_korisnik_tip_id']=$tip;
				$_SESSION["aktivni_korisnik_ime_i_prezime"]=$ime." ".$prezime;
				$_SESSION["aktivni_korisnik_korime"]=$korime;
				header("Location:index.php");
			}
		}
		else $greska = "Molim unesite korisničko ime i lozinku";
	}
	if (session_id() == '') {
		session_start();
	}
	if (isset($_SESSION['korisnik.korime'])) {
		if ($_SESSION['tip_korisnika_id'] == 0) {
			$uloga = "administrator";
		} else if ($_SESSION['tip_korisnika_id'] == 1) {
			$uloga = "moderator";
		} else if ($_SESSION['tip_korisnika_id'] == 2) {
			$uloga = "korisnik";
		}
		$porukasesije = '<a id="porukaprijave" href="logout.php">Korisnik: ' . $_SESSION['korisnik_korime'] . ' ('.$uloga.')'.'<br> Odjava</a>';
	} else {
		$porukasesije = '<a id="porukaprijave"> Korisnik nije prijavljen.</a>';
	}
	?>

<form id="prijava" name="prijava" method="POST" action="login.php">
	<table>
		<caption>Prijava</caption>
		<tbody>
			<tr>
					<td colspan="2" style="text-align:center;">
						<label class="greska">
							<?php if($greska!="")echo $greska; ?>
						</label>
					</td>
			</tr>
			<tr>
				<td class="lijevi">
					<label for="korime"><strong>Korisničko ime:</strong></label>
				</td>
				<td>
					<input name="korime" id="korime" type="text" size="120"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="lozinka"><strong>Lozinka:</strong></label>
				</td>
				<td>
					<input name="lozinka"	id="lozinka" type="password" size="120"/>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Prijavi se"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>
<?php
	zatvoriVezuNaBazu($bp);
	include("podnozje.php");
?>
