<?php
include("zaglavlje.php");
$bp = spojiSeNaBazu();

if (isset($_GET['odobri'])){
    $sql = "UPDATE `zahtjev_podrucja` 
        SET `status`='1' 
        WHERE `moderator_id`='{$_GET['moderator']}' AND `znanstveno_podrucje_id`='{$_GET['podrucje']}'";
    izvrsiUpit($bp, $sql);

    $sql = "UPDATE `korisnik` SET `znanstveno_podrucje_id`='{$_GET['podrucje']}'
        WHERE korisnik_id = {$_GET['moderator']}";
    izvrsiUpit($bp, $sql);
}
if (isset($_GET['odbij'])){
    $sql = "UPDATE `zahtjev_podrucja` 
        SET `status`='0' 
        WHERE `moderator_id`='{$_GET['moderator']}' AND `znanstveno_podrucje_id`='{$_GET['podrucje']}'";
    izvrsiUpit($bp, $sql);
}

$sql = "SELECT zahtjev_podrucja.*, korisnik.ime, korisnik.prezime, znanstveno_podrucje.naziv FROM `zahtjev_podrucja` INNER JOIN korisnik ON korisnik.korisnik_id = zahtjev_podrucja.moderator_id INNER JOIN znanstveno_podrucje ON zahtjev_podrucja.znanstveno_podrucje_id = znanstveno_podrucje.znanstveno_podrucje_id ORDER BY status DESC;";
$rs = izvrsiUpit($bp, $sql);

zatvoriVezuNaBazu($bp);
?>

<article>
    <div id="opis">
        <h2>Popis zahtjeva za promjenom znanstvenog područja</h2>
    </div>

    <table>

        <thead>
            <th>Ime i prezime znanstvenika</th>
            <th>Odabrano područje</th>
            <th>Status</th>
        </thead>
        <tbody>
            <?php
                while($red = mysqli_fetch_array($rs)){

                    switch($red['status']){
                        case 0:
                            $status = "odbijen";
                            break;
                        case 1:
                            $status = "odobren"; 
                            break;
                        case 2:
                            $status = "čeka odobrenje";
                            break;
                        default:
                            $status = "nepoznata status";
                    }

                    echo "<tr>
                        <td>{$red['ime']} {$red['prezime']}</td>
                        <td>{$red['naziv']}</td>
                        <td>{$status}</td>";

                    if ($red['status'] == 2) {
                        echo "
                        <td><a href='zahtjevi.php?odobri=1&moderator={$red['moderator_id']}&podrucje={$red['znanstveno_podrucje_id']}'><button>Odobri</button></a></td>
                        <td><a href='zahtjevi.php?odbij=1&moderator={$red['moderator_id']}&podrucje={$red['znanstveno_podrucje_id']}'><button>Odbij</button></a></td>
                        ";
                    }
                    
                    echo "
                        </tr>
                    ";
                }
            ?>
        </tbody>
    </table>


</article>


<?php
include("podnozje.php");
?>